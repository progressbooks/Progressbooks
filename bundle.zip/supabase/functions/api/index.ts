// Progress Books server function: email, customer quote/invoice links, card payments,
// daily reminders and team logins. Deployed with JWT verification off; each action checks access itself.
import { createClient } from "npm:@supabase/supabase-js@2.45.4";

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SERVICE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const RESEND_API_KEY = Deno.env.get("RESEND_API_KEY") || "";
const STRIPE_SECRET_KEY = Deno.env.get("STRIPE_SECRET_KEY") || "";
const STRIPE_WEBHOOK_SECRET = Deno.env.get("STRIPE_WEBHOOK_SECRET") || "";
const APP_URL = (Deno.env.get("APP_URL") || "").replace(/\/+$/, "");
const FROM_EMAIL = Deno.env.get("FROM_EMAIL") || "Progress Trade Services <quotes@progresstradeservices.com.au>";
const REPLY_TO = Deno.env.get("REPLY_TO") || "progresstradeservices@hotmail.com";

const db = createClient(SUPABASE_URL, SERVICE_KEY, { auth: { persistSession: false, autoRefreshToken: false } });

const CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, apikey, content-type, x-client-info",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};
const json = (body: unknown, status = 200) =>
  new Response(JSON.stringify(body), { status, headers: { ...CORS, "Content-Type": "application/json" } });
class HttpError extends Error { constructor(public status: number, msg: string) { super(msg); } }
const fail = (status: number, msg: string): never => { throw new HttpError(status, msg); };

// ---------- small helpers ----------
const r2 = (n: unknown) => Math.round((Number(n) || 0) * 100) / 100;
const money = (n: number) => (Number(n) || 0).toLocaleString("en-AU", { style: "currency", currency: "AUD" });
const melToday = () => new Intl.DateTimeFormat("en-CA", { timeZone: "Australia/Melbourne" }).format(new Date());
const daysBetween = (a: string, b: string) => Math.round((Date.parse(a + "T00:00:00Z") - Date.parse(b + "T00:00:00Z")) / 864e5);
const fmtDate = (iso: string) => iso ? new Date(iso + "T00:00:00Z").toLocaleDateString("en-AU", { day: "numeric", month: "short", year: "numeric", timeZone: "UTC" }) : "";
const esc = (s: unknown) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]!));
const isEmail = (s: string) => /^[^\s@,;<>]+@[^\s@,;<>]+\.[^\s@,;<>]+$/.test(s);
const randomToken = () => Array.from(crypto.getRandomValues(new Uint8Array(18)), (b) => b.toString(16).padStart(2, "0")).join("");

type Line = { desc: string; qty: number; price: number; gst: boolean };
function totals(lines: Line[] = [], gstOn: boolean) {
  let sub = 0, gst = 0;
  for (const l of lines) { const a = r2((+l.qty || 0) * (+l.price || 0)); sub += a; if (l.gst && gstOn) gst += a * 0.1; }
  sub = r2(sub); gst = r2(gst);
  return { sub, gst, total: r2(sub + gst) };
}

async function getRecord(collection: string, id: string) {
  const { data, error } = await db.from("records").select("data").eq("collection", collection).eq("id", id).maybeSingle();
  if (error) throw error;
  return data ? (data.data as Record<string, any>) : null;
}
async function patchRecord(collection: string, id: string, patch: Record<string, unknown>) {
  const cur = (await getRecord(collection, id)) || {};
  const next = { ...cur, ...patch, updatedAt: new Date().toISOString() };
  const { error } = await db.from("records").upsert({ collection, id, data: next, updated_at: new Date().toISOString() });
  if (error) throw error;
  return next;
}
async function loadAll(collection: string) {
  const out: { id: string; data: Record<string, any> }[] = [];
  for (let from = 0; ; from += 1000) {
    const { data, error } = await db.from("records").select("id,data").eq("collection", collection).range(from, from + 999);
    if (error) throw error;
    out.push(...(data as any[]));
    if (!data || data.length < 1000) break;
  }
  return out;
}
const settings = async () => ((await getRecord("settings", "business")) || {}) as Record<string, any>;
const gstOn = (s: Record<string, any>) => s.gstRegistered !== false;
const viewUrl = (token: string) => `${APP_URL}/view.html?t=${token}`;

async function ensureLink(collection: string, id: string) {
  const { data } = await db.from("links").select("token").eq("collection", collection).eq("id", id).maybeSingle();
  if (data?.token) return data.token as string;
  const token = randomToken();
  const { error } = await db.from("links").insert({ token, collection, id });
  if (error) {
    const again = await db.from("links").select("token").eq("collection", collection).eq("id", id).maybeSingle();
    if (again.data?.token) return again.data.token as string;
    throw error;
  }
  await patchRecord(collection, id, { linkToken: token });
  return token;
}
async function fromToken(token: string) {
  if (!/^[a-f0-9]{20,64}$/.test(token || "")) fail(404, "This link isn't valid.");
  const { data } = await db.from("links").select("collection,id").eq("token", token).maybeSingle();
  if (!data) fail(404, "This link isn't valid or has been removed.");
  const rec = await getRecord(data!.collection, data!.id);
  if (!rec) fail(404, "This document no longer exists.");
  return { collection: data!.collection as string, id: data!.id as string, rec: rec! };
}

// ---------- access ----------
async function member(req: Request) {
  const jwt = (req.headers.get("authorization") || "").replace(/^Bearer\s+/i, "");
  if (!jwt) fail(401, "Please sign in again.");
  const { data, error } = await db.auth.getUser(jwt);
  if (error || !data?.user?.email) fail(401, "Please sign in again.");
  const email = data.user!.email!.toLowerCase();
  const { data: rows } = await db.from("members").select("email,role,name");
  const m = (rows || []).find((r: any) => String(r.email).toLowerCase() === email);
  if (!m) fail(403, "This login hasn't been given access. Ask the owner to add you.");
  return { email, role: m!.role as string, name: m!.name as string, userId: data.user!.id };
}
const writer = async (req: Request) => { const m = await member(req); if (m.role === "accountant") fail(403, "Your login is read-only."); return m; };
const owner = async (req: Request) => { const m = await member(req); if (m.role !== "owner") fail(403, "Only the owner can do this."); return m; };

// ---------- email ----------
function emailHtml(bizName: string, message: string, button?: { label: string; url: string }) {
  const body = esc(message).replace(/\r?\n/g, "<br>");
  const logo = APP_URL ? `<img src="${APP_URL}/logo.png" alt="${esc(bizName)}" width="200" style="display:block;max-width:200px;height:auto;margin:0 0 20px">` : `<h2 style="margin:0 0 20px">${esc(bizName)}</h2>`;
  const btn = button ? `<p style="margin:24px 0"><a href="${esc(button.url)}" style="background:#4f8a1c;color:#ffffff;text-decoration:none;font-weight:bold;padding:12px 20px;border-radius:6px;display:inline-block">${esc(button.label)}</a></p>` : "";
  return `<!doctype html><html><body style="margin:0;background:#f3f5f3;font-family:Arial,Helvetica,sans-serif;color:#222">
<table role="presentation" width="100%" cellpadding="0" cellspacing="0"><tr><td align="center" style="padding:24px 12px">
<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="max-width:560px;background:#ffffff;border-radius:8px"><tr><td style="padding:28px;font-size:15px;line-height:1.55">
${logo}<div>${body}</div>${btn}</td></tr></table></td></tr></table></body></html>`;
}
async function sendEmail(o: { to: string[]; subject: string; text: string; html: string; attachments?: { filename: string; content: string }[] }) {
  if (!RESEND_API_KEY) fail(400, "Email sending isn't set up yet. Add your Resend key first.");
  const res = await fetch("https://api.resend.com/emails", {
    method: "POST",
    headers: { Authorization: `Bearer ${RESEND_API_KEY}`, "Content-Type": "application/json" },
    body: JSON.stringify({ from: FROM_EMAIL, to: o.to, reply_to: REPLY_TO, subject: o.subject, text: o.text, html: o.html, attachments: o.attachments }),
  });
  const out = await res.json().catch(() => ({}));
  if (!res.ok) fail(502, `The email wasn't sent: ${out?.message || res.statusText}`);
  return out?.id as string;
}
const logPush = (rec: Record<string, any>, entry: Record<string, unknown>) => [...(rec.emailLog || []), { at: new Date().toISOString(), ...entry }].slice(-20);

function documentButton(rec: Record<string, any>, token: string, s: Record<string, any>) {
  if (!APP_URL) return undefined;
  if (rec.kind === "quote") return rec.status === "accepted" || rec.status === "declined" ? { label: "View quote", url: viewUrl(token) } : { label: "View & accept quote", url: viewUrl(token) };
  if (rec.status === "paid") return { label: "View invoice", url: viewUrl(token) };
  if (STRIPE_SECRET_KEY) return { label: "View & pay invoice", url: viewUrl(token) };
  if (s.payLink) return { label: "Pay now", url: s.payLink };
  return { label: "View invoice", url: viewUrl(token) };
}

// ---------- actions ----------
async function actSend(req: Request, b: any) {
  const m = await writer(req);
  const to = String(b.to || "").split(/[,;\s]+/).map((x) => x.trim()).filter(Boolean);
  if (!to.length || !to.every(isEmail)) fail(400, "Enter a valid customer email address.");
  if (to.length > 5) fail(400, "Send to 5 addresses or fewer.");
  const rec = await getRecord("invoices", String(b.id || ""));
  if (!rec) fail(404, "Save the quote or invoice first.");
  const s = await settings();
  const token = await ensureLink("invoices", b.id);
  const pdf = String(b.pdf || "").replace(/^data:[^,]+,/, "");
  if (pdf.length > 9_000_000) fail(400, "The PDF is too large to email.");
  const message = String(b.message || "").slice(0, 8000);
  const subject = String(b.subject || `${rec!.kind === "quote" ? "Quote" : "Invoice"} ${rec!.number}`).slice(0, 200);
  const btn = documentButton(rec!, token, s);
  const text = message + (btn ? `\n\n${btn.label}: ${btn.url}` : "");
  await sendEmail({ to, subject, text, html: emailHtml(s.name || "Progress Trade Services", message, btn), attachments: pdf ? [{ filename: String(b.filename || `${rec!.number}.pdf`).replace(/[^\w .()-]/g, "_"), content: pdf }] : undefined });
  const fresh = (await getRecord("invoices", b.id)) || rec!;
  const patch: Record<string, unknown> = { sentTo: to.join(", "), lastSentAt: new Date().toISOString(), emailLog: logPush(fresh, { type: "sent", to: to.join(", "), by: m.email }) };
  if (!fresh.status || fresh.status === "draft") { patch.status = "sent"; patch.sentDate = melToday(); }
  await patchRecord("invoices", b.id, patch);
  return { ok: true, url: viewUrl(token) };
}

async function actLink(req: Request, b: any) {
  await writer(req);
  if (!(await getRecord("invoices", String(b.id || "")))) fail(404, "Save the quote or invoice first.");
  const token = await ensureLink("invoices", b.id);
  return { token, url: viewUrl(token) };
}

async function actPublicGet(b: any) {
  const { collection, id, rec } = await fromToken(String(b.token || ""));
  if (collection !== "invoices") fail(404, "This link isn't valid.");
  const s = await settings();
  const c = rec.customerId ? await getRecord("customers", rec.customerId) : null;
  const t = totals(rec.lines, gstOn(s));
  if (!rec.viewedAt) await patchRecord(collection, id, { viewedAt: new Date().toISOString() });
  return {
    business: { name: s.name || "Progress Trade Services", abn: s.abn || "", licence: s.licence || "", phone: s.phone || "", email: s.email || "", address: s.address || "", payId: s.payId || "", bankName: s.bankName || "", bsb: s.bsb || "", acct: s.acct || "", gstRegistered: gstOn(s), payLink: s.payLink || "" },
    doc: {
      kind: rec.kind, number: rec.number, date: rec.date, due: rec.due, status: rec.status || "draft", paidDate: rec.paidDate || "",
      lines: (rec.lines || []).map((l: Line) => ({ desc: l.desc, qty: l.qty, price: l.price, gst: !!l.gst })),
      subtotal: t.sub, gst: t.gst, total: t.total, notes: rec.notes || "", footer: rec.kind === "invoice" ? (s.footer || "") : "",
      customer: { name: c?.name || rec.customerName || "", address: c?.address || "" },
      acceptedBy: rec.acceptedBy || "", decidedDate: rec.decidedDate || "",
    },
    payOnline: rec.kind === "invoice" && rec.status !== "paid" && !!STRIPE_SECRET_KEY,
    today: melToday(),
  };
}

async function actPublicDecide(b: any) {
  const { id, rec } = await fromToken(String(b.token || ""));
  if (rec.kind !== "quote") fail(400, "Only quotes can be accepted.");
  if (rec.status === "accepted" || rec.status === "declined") return { ok: true, status: rec.status };
  const decision = b.decision === "decline" ? "declined" : "accepted";
  const name = String(b.name || "").trim().slice(0, 80);
  if (decision === "accepted" && !name) fail(400, "Please type your name to accept.");
  const comment = String(b.comment || "").trim().slice(0, 500);
  await patchRecord("invoices", id, { status: decision, decidedDate: melToday(), acceptedBy: name, decidedAt: new Date().toISOString(), customerComment: comment, decidedOnline: true });
  if (RESEND_API_KEY) {
    const s = await settings();
    const c = rec.customerId ? await getRecord("customers", rec.customerId) : null;
    const who = name || c?.name || rec.customerName || "The customer";
    const t = totals(rec.lines, gstOn(s));
    const msg = decision === "accepted"
      ? `${who} accepted ${rec.number} (${money(t.total)}) online on ${fmtDate(melToday())}.${comment ? `\n\nTheir note: ${comment}` : ""}\n\nOpen Progress Books to book the job or make the invoice.`
      : `${c?.name || rec.customerName || "The customer"} declined ${rec.number} (${money(t.total)}).${comment ? `\n\nTheir note: ${comment}` : ""}`;
    try { await sendEmail({ to: [REPLY_TO], subject: `${rec.number} ${decision} by ${c?.name || rec.customerName || "customer"}`, text: msg, html: emailHtml(s.name || "Progress Trade Services", msg, APP_URL ? { label: "Open Progress Books", url: APP_URL } : undefined) }); } catch (_) { /* the decision is saved either way */ }
  }
  return { ok: true, status: decision };
}

async function stripe(path: string, params: Record<string, string>) {
  const res = await fetch(`https://api.stripe.com/v1/${path}`, {
    method: "POST",
    headers: { Authorization: `Bearer ${STRIPE_SECRET_KEY}`, "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams(params),
  });
  const out = await res.json();
  if (!res.ok) fail(502, out?.error?.message || "The payment page couldn't be opened.");
  return out;
}
async function actPublicPay(b: any) {
  if (!STRIPE_SECRET_KEY) fail(400, "Card payments aren't set up yet.");
  const token = String(b.token || "");
  const { id, rec } = await fromToken(token);
  if (rec.kind !== "invoice") fail(400, "Only invoices can be paid.");
  if (rec.status === "paid") fail(400, "This invoice is already paid. Thank you.");
  const s = await settings();
  const t = totals(rec.lines, gstOn(s));
  const cents = Math.round(t.total * 100);
  if (cents < 50) fail(400, "This invoice amount is too small to pay by card.");
  const c = rec.customerId ? await getRecord("customers", rec.customerId) : null;
  const params: Record<string, string> = {
    mode: "payment",
    "line_items[0][quantity]": "1",
    "line_items[0][price_data][currency]": "aud",
    "line_items[0][price_data][unit_amount]": String(cents),
    "line_items[0][price_data][product_data][name]": `Invoice ${rec.number} – ${s.name || "Progress Trade Services"}`,
    "metadata[record_id]": id,
    "metadata[invoice_number]": String(rec.number || ""),
    "payment_intent_data[metadata][record_id]": id,
    "payment_intent_data[description]": `Invoice ${rec.number}`,
    success_url: `${viewUrl(token)}&paid=1`,
    cancel_url: viewUrl(token),
  };
  if (c?.email && isEmail(c.email)) params.customer_email = c.email;
  const session = await stripe("checkout/sessions", params);
  return { url: session.url };
}

async function verifyStripe(payload: string, header: string) {
  if (!STRIPE_WEBHOOK_SECRET) return false;
  const parts = Object.fromEntries(header.split(",").map((p) => p.split("=") as [string, string]).filter((p) => p.length === 2 && p[0] === "t"));
  const sigs = header.split(",").filter((p) => p.startsWith("v1=")).map((p) => p.slice(3));
  const t = parts.t;
  if (!t || !sigs.length) return false;
  if (Math.abs(Date.now() / 1000 - Number(t)) > 600) return false;
  const key = await crypto.subtle.importKey("raw", new TextEncoder().encode(STRIPE_WEBHOOK_SECRET), { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
  const mac = new Uint8Array(await crypto.subtle.sign("HMAC", key, new TextEncoder().encode(`${t}.${payload}`)));
  const hex = Array.from(mac, (x) => x.toString(16).padStart(2, "0")).join("");
  return sigs.some((s) => s.length === hex.length && [...s].reduce((acc, ch, i) => acc | (ch.charCodeAt(0) ^ hex.charCodeAt(i)), 0) === 0);
}
async function stripeWebhook(req: Request) {
  const payload = await req.text();
  if (!(await verifyStripe(payload, req.headers.get("stripe-signature") || ""))) return json({ error: "bad signature" }, 400);
  const event = JSON.parse(payload);
  if (event.type === "checkout.session.completed" || event.type === "checkout.session.async_payment_succeeded") {
    const sess = event.data.object;
    const id = sess?.metadata?.record_id;
    if (id && sess.payment_status === "paid") {
      const rec = await getRecord("invoices", id);
      if (rec && rec.status !== "paid") {
        await patchRecord("invoices", id, { status: "paid", paidDate: melToday(), method: "Card (online)", stripeSession: sess.id, paidAmount: r2((sess.amount_total || 0) / 100) });
        if (RESEND_API_KEY) {
          const s = await settings();
          const msg = `${rec.customerName || "A customer"} paid ${rec.number} by card: ${money((sess.amount_total || 0) / 100)}. It's been marked as paid in Progress Books.`;
          try { await sendEmail({ to: [REPLY_TO], subject: `Payment received for ${rec.number}`, text: msg, html: emailHtml(s.name || "Progress Trade Services", msg) }); } catch (_) { /* invoice already updated */ }
        }
      }
    }
  }
  return json({ received: true });
}

async function actReminders(req: Request) {
  const secret = req.headers.get("x-cron-secret") || "";
  let manual = false;
  if (secret) {
    const { data } = await db.from("app_secrets").select("value").eq("key", "cron").maybeSingle();
    if (!data || data.value !== secret) fail(403, "Not allowed.");
  } else { await owner(req); manual = true; }
  if (!RESEND_API_KEY) return { sent: 0, note: "Email isn't set up yet." };
  const s = await settings();
  const today = melToday();
  const biz = s.name || "Progress Trade Services";
  const customers = new Map((await loadAll("customers")).map((r) => [r.id, r.data]));
  let sent = 0; const errors: string[] = [];
  const limit = 60;

  if (s.remindersOn) {
    const steps = String(s.reminderDays ?? "3, 7, 14").split(/[^\d]+/).map(Number).filter((n) => n > 0 && n < 366).sort((a, b) => b - a);
    for (const { id, data: inv } of await loadAll("invoices")) {
      if (sent >= limit) break;
      if (inv.kind !== "invoice" || inv.status !== "sent") continue;
      const late = daysBetween(today, inv.due || inv.date);
      const done: string[] = inv.remindersSent || [];
      const step = steps.find((n) => n <= late && !done.includes(`after${n}`));
      if (!step || late - step > 14) continue;
      const c = customers.get(inv.customerId) || {};
      if (!c.email || !isEmail(c.email)) continue;
      const t = totals(inv.lines, gstOn(s));
      const token = await ensureLink("invoices", id);
      const first = String(c.name || inv.customerName || "").split(/\s+/)[0] || "there";
      const msg = `Hi ${first},\n\nThis is a friendly reminder that invoice ${inv.number} for ${money(t.total)} was due on ${fmtDate(inv.due || inv.date)} and is now ${late} day${late === 1 ? "" : "s"} overdue.\n\nIf you've already paid, thank you, and please ignore this email. Otherwise you can view and pay it using the button below, or contact us with any questions.\n\nKind regards,\n${biz}${s.phone ? "\n" + s.phone : ""}`;
      try {
        const btn = documentButton(inv, token, s);
        await sendEmail({ to: [c.email], subject: `Reminder: invoice ${inv.number} is overdue`, text: msg + (btn ? `\n\n${btn.label}: ${btn.url}` : ""), html: emailHtml(biz, msg, btn) });
        const fresh = (await getRecord("invoices", id)) || inv;
        await patchRecord("invoices", id, { remindersSent: [...new Set([...done, ...steps.filter((n) => n <= step).map((n) => `after${n}`)])], emailLog: logPush(fresh, { type: `reminder ${step} days`, to: c.email }) });
        sent++;
      } catch (e) { errors.push(`${inv.number}: ${(e as Error).message}`); }
    }
  }

  if (s.serviceRemindersOn) {
    const lead = Number(s.serviceLeadDays ?? 14) || 14;
    for (const { id, data: job } of await loadAll("jobs")) {
      if (sent >= limit) break;
      if (!job.nextService || job.serviceReminderFor === job.nextService) continue;
      const until = daysBetween(job.nextService, today);
      if (until < 0 || until > lead) continue;
      const c = customers.get(job.customerId) || {};
      if (!c.email || !isEmail(c.email)) continue;
      const first = String(c.name || job.customerName || "").split(/\s+/)[0] || "there";
      const what = job.type === "Pest control" ? "pest control service" : "service";
      const msg = `Hi ${first},\n\nYour next ${what}${job.address ? ` at ${job.address}` : ""} is due around ${fmtDate(job.nextService)}.\n\nTo book a time, simply reply to this email${s.phone ? ` or call us on ${s.phone}` : ""}.\n\nKind regards,\n${biz}`;
      try {
        await sendEmail({ to: [c.email], subject: `Your next ${what} is due`, text: msg, html: emailHtml(biz, msg) });
        await patchRecord("jobs", id, { serviceReminderFor: job.nextService, serviceReminderAt: new Date().toISOString() });
        sent++;
      } catch (e) { errors.push(`${job.title || "job"}: ${(e as Error).message}`); }
    }
  }
  return { sent, errors, manual };
}

async function findUser(email: string) {
  for (let page = 1; page <= 20; page++) {
    const { data, error } = await db.auth.admin.listUsers({ page, perPage: 200 });
    if (error) throw error;
    const u = data.users.find((x: any) => (x.email || "").toLowerCase() === email);
    if (u) return u;
    if (data.users.length < 200) return null;
  }
  return null;
}
async function actTeamSave(req: Request, b: any) {
  const me = await owner(req);
  const email = String(b.email || "").trim().toLowerCase();
  if (!isEmail(email)) fail(400, "Enter a valid email address.");
  const role = ["owner", "staff", "accountant"].includes(b.role) ? b.role : "staff";
  if (email === me.email && role !== "owner") fail(400, "You can't remove your own owner access.");
  const password = String(b.password || "");
  if (password && password.length < 8) fail(400, "Use a password of at least 8 characters.");
  const existing = await findUser(email);
  if (existing && password) {
    const { error } = await db.auth.admin.updateUserById(existing.id, { password, email_confirm: true });
    if (error) fail(400, error.message);
  } else if (!existing) {
    if (!password) fail(400, "Set a starting password for this new login.");
    const { error } = await db.auth.admin.createUser({ email, password, email_confirm: true });
    if (error) fail(400, error.message);
  }
  const { error } = await db.from("members").upsert({ email, role, name: String(b.name || "").slice(0, 80) });
  if (error) fail(400, error.message);
  return { ok: true };
}
async function actTeamRemove(req: Request, b: any) {
  const me = await owner(req);
  const email = String(b.email || "").trim().toLowerCase();
  if (email === me.email) fail(400, "You can't remove yourself.");
  const { data: rows } = await db.from("members").select("email");
  const match = (rows || []).find((r: any) => String(r.email).toLowerCase() === email);
  if (match) await db.from("members").delete().eq("email", match.email);
  return { ok: true };
}
async function actStatus(req: Request) {
  const m = await member(req);
  return { email: !!RESEND_API_KEY, stripe: !!STRIPE_SECRET_KEY, webhook: !!STRIPE_WEBHOOK_SECRET, appUrl: APP_URL, from: FROM_EMAIL, replyTo: REPLY_TO, role: m.role, me: m.email };
}
async function actTestEmail(req: Request) {
  const m = await owner(req);
  const s = await settings();
  const msg = `This is a test email from Progress Books.\n\nIf you're reading this in your inbox, email sending is working. Replies to emails from the app come back to ${REPLY_TO}.`;
  await sendEmail({ to: [m.email], subject: "Progress Books test email", text: msg, html: emailHtml(s.name || "Progress Trade Services", msg) });
  return { ok: true, to: m.email };
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: CORS });
  if (req.method !== "POST") return json({ error: "Not found" }, 404);
  try {
    if (req.headers.get("stripe-signature")) return await stripeWebhook(req);
    const b = await req.json().catch(() => ({}));
    switch (b.action) {
      case "status": return json(await actStatus(req));
      case "send": return json(await actSend(req, b));
      case "link": return json(await actLink(req, b));
      case "public-get": return json(await actPublicGet(b));
      case "public-decide": return json(await actPublicDecide(b));
      case "public-pay": return json(await actPublicPay(b));
      case "reminders": return json(await actReminders(req));
      case "team-save": return json(await actTeamSave(req, b));
      case "team-remove": return json(await actTeamRemove(req, b));
      case "test-email": return json(await actTestEmail(req));
      default: return json({ error: "Unknown request." }, 400);
    }
  } catch (e) {
    if (e instanceof HttpError) return json({ error: e.message }, e.status);
    console.error(e);
    return json({ error: "Something went wrong. Please try again." }, 500);
  }
});

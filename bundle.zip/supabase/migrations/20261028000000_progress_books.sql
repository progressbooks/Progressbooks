-- Progress Books database. Safe to run more than once.

-- ---------- tables ----------
create table if not exists public.members (
  email text primary key,
  role text not null default 'staff'
);
alter table public.members add column if not exists name text not null default '';
alter table public.members drop constraint if exists members_role_check;
alter table public.members add constraint members_role_check check (role in ('owner','staff','accountant'));

create table if not exists public.records (
  collection text not null,
  id text not null,
  data jsonb not null,
  updated_at timestamptz not null default now(),
  primary key (collection, id)
);

-- Share links customers open to view, accept or pay
create table if not exists public.links (
  token text primary key,
  collection text not null,
  id text not null,
  created_at timestamptz not null default now(),
  unique (collection, id)
);

-- Server-only values (never readable by the app)
create table if not exists public.app_secrets (
  key text primary key,
  value text not null
);
insert into public.app_secrets (key, value)
values ('cron', replace(gen_random_uuid()::text || gen_random_uuid()::text, '-', ''))
on conflict (key) do nothing;

alter table public.members enable row level security;
alter table public.records enable row level security;
alter table public.links enable row level security;
alter table public.app_secrets enable row level security;

-- ---------- who can do what ----------
create or replace function public.member_role()
returns text language sql security definer stable set search_path = public as $$
  select role from public.members where lower(email) = lower(auth.jwt() ->> 'email') limit 1
$$;
create or replace function public.is_member()
returns boolean language sql security definer stable set search_path = public as $$
  select public.member_role() is not null
$$;
create or replace function public.can_write()
returns boolean language sql security definer stable set search_path = public as $$
  select coalesce(public.member_role() in ('owner','staff'), false)
$$;
create or replace function public.is_owner()
returns boolean language sql security definer stable set search_path = public as $$
  select coalesce(public.member_role() = 'owner', false)
$$;

drop policy if exists "members read members" on public.members;
create policy "members read members" on public.members for select to authenticated using (public.is_member());
drop policy if exists "owner manages members" on public.members;
create policy "owner manages members" on public.members for all to authenticated using (public.is_owner()) with check (public.is_owner());

drop policy if exists "members read records" on public.records;
create policy "members read records" on public.records for select to authenticated using (public.is_member());
drop policy if exists "members add records" on public.records;
create policy "members add records" on public.records for insert to authenticated with check (public.can_write());
drop policy if exists "members change records" on public.records;
create policy "members change records" on public.records for update to authenticated using (public.can_write()) with check (public.can_write());
drop policy if exists "members delete records" on public.records;
create policy "members delete records" on public.records for delete to authenticated using (public.can_write());

drop policy if exists "members read links" on public.links;
create policy "members read links" on public.links for select to authenticated using (public.is_member());

grant usage on schema public to authenticated;
grant select, insert, update, delete on public.records to authenticated;
grant select, insert, update, delete on public.members to authenticated;
grant select on public.links to authenticated;
grant execute on function public.member_role(), public.is_member(), public.can_write(), public.is_owner() to authenticated;
revoke all on public.records, public.members, public.links, public.app_secrets from anon;
revoke all on public.app_secrets from authenticated;

-- ---------- receipt photos ----------
insert into storage.buckets (id, name, public) values ('receipts', 'receipts', false) on conflict (id) do nothing;
drop policy if exists "members view receipts" on storage.objects;
create policy "members view receipts" on storage.objects for select to authenticated using (bucket_id = 'receipts' and public.is_member());
drop policy if exists "members upload receipts" on storage.objects;
create policy "members upload receipts" on storage.objects for insert to authenticated with check (bucket_id = 'receipts' and public.can_write());
drop policy if exists "members delete receipts" on storage.objects;
create policy "members delete receipts" on storage.objects for delete to authenticated using (bucket_id = 'receipts' and public.can_write());

-- ---------- live updates ----------
do $$ begin
  if not exists (select 1 from pg_publication_tables where pubname = 'supabase_realtime' and schemaname = 'public' and tablename = 'records') then
    alter publication supabase_realtime add table public.records;
  end if;
end $$;

-- ---------- owner ----------
insert into public.members (email, role, name)
values ('progresstradeservices@hotmail.com', 'owner', 'Owner')
on conflict (email) do update set role = 'owner';

-- ---------- daily reminders (9am Melbourne in summer, 8am in winter) ----------
create extension if not exists pg_cron;
create extension if not exists pg_net with schema extensions;

do $$ begin
  if exists (select 1 from cron.job where jobname = 'progress-books-reminders') then
    perform cron.unschedule('progress-books-reminders');
  end if;
end $$;

select cron.schedule(
  'progress-books-reminders',
  '0 22 * * *',
  $cron$
  select net.http_post(
    url := 'https://__PROJECT_REF__.supabase.co/functions/v1/api',
    headers := jsonb_build_object('Content-Type', 'application/json', 'x-cron-secret', (select value from public.app_secrets where key = 'cron')),
    body := '{"action":"reminders"}'::jsonb
  );
  $cron$
);

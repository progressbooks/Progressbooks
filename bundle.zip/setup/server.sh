#!/usr/bin/env bash
set -euo pipefail
for v in REF SUPABASE_ACCESS_TOKEN SUPABASE_DB_PASSWORD; do
  if [ -z "${!v:-}" ]; then echo "::error::Missing secret for $v"; exit 1; fi
done
APP_URL="${APP_URL%/}"
sed -i "s/__PROJECT_REF__/$REF/g" supabase/migrations/*.sql
supabase link --project-ref "$REF" --password "$SUPABASE_DB_PASSWORD"
supabase db push --include-all --password "$SUPABASE_DB_PASSWORD"
supabase secrets set --project-ref "$REF" "APP_URL=$APP_URL" "FROM_EMAIL=Progress Trade Services <quotes@progresstradeservices.com.au>" "REPLY_TO=progresstradeservices@hotmail.com"
if [ -n "${RESEND_API_KEY:-}" ]; then supabase secrets set --project-ref "$REF" "RESEND_API_KEY=$RESEND_API_KEY"; fi
if [ -n "${STRIPE_SECRET_KEY:-}" ]; then supabase secrets set --project-ref "$REF" "STRIPE_SECRET_KEY=$STRIPE_SECRET_KEY"; fi
if [ -n "${STRIPE_WEBHOOK_SECRET:-}" ]; then supabase secrets set --project-ref "$REF" "STRIPE_WEBHOOK_SECRET=$STRIPE_WEBHOOK_SECRET"; fi
supabase functions deploy api --project-ref "$REF" --no-verify-jwt
echo "Published. App address: $APP_URL"

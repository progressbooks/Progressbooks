#!/usr/bin/env bash
set -euo pipefail
if [ -z "${REF:-}" ] || [ -z "${KEY:-}" ]; then echo "::error::Add the SUPABASE_PROJECT_REF and SUPABASE_ANON_KEY secrets first."; exit 1; fi
printf 'window.PB_CONFIG = { url: "https://%s.supabase.co", key: "%s" };\n' "$REF" "$KEY" > web/config.js
